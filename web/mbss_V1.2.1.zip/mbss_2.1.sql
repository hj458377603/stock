CREATE TABLE `mbss_about_me` (
  `account_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `circle_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '圈子ID',
  `topic_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '话题id',
  `reply_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '跟帖id',
  `create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`account_id`,`circle_id`,`topic_id`,`reply_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='我关注的表';

CREATE TABLE `mbss_account` (
  `account_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '帐号ID',
  `nickname` varchar(20) NOT NULL COMMENT '昵称',
  `icon_url` longtext COMMENT '头像地址',
  `account_source` smallint(6) DEFAULT '0' COMMENT '0:未知 1:ios 2:android 3:wap',
  `package_channel` varchar(50) DEFAULT NULL COMMENT '渠道包',
  `created_datetime` datetime NOT NULL COMMENT '创建时间',
  `account_state` smallint(4) NOT NULL DEFAULT '1',
  `account_score` int(11) DEFAULT '0' COMMENT '用户积分',
  `is_joined_circle` int(11) DEFAULT '0' COMMENT '是否加入过圈子',
  `is_auth_post` int(11) DEFAULT '0' COMMENT '是否禁言  默认0,   1:禁言（不能发帖）',
  PRIMARY KEY (`account_id`),
  KEY `IX_ACCOUNT_SOURCE` (`account_source`)
) ENGINE=InnoDB AUTO_INCREMENT=346 DEFAULT CHARSET=utf8;

CREATE TABLE `mbss_account_device` (
  `account_device_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增序号',
  `account_id` int(11) NOT NULL COMMENT '帐号ID',
  `device_type` smallint(6) NOT NULL COMMENT '设备类型',
  `device_id` varchar(128) NOT NULL COMMENT '设备ID',
  `device_name` varchar(20) NOT NULL COMMENT '设备名称',
  `login_datetime` datetime NOT NULL COMMENT '最近登录时间',
  `device_state` smallint(6) NOT NULL COMMENT '设备状态',
  PRIMARY KEY (`account_device_id`),
  KEY `ix_device_account_id` (`account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3204 DEFAULT CHARSET=utf8mb4;

CREATE TABLE `mbss_account_login_history` (
  `login_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '登录历史序列',
  `account_id` int(11) NOT NULL COMMENT '帐号ID',
  `login_datetime` datetime NOT NULL COMMENT '登录时间',
  PRIMARY KEY (`login_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10931 DEFAULT CHARSET=utf8;

CREATE TABLE `mbss_account_msg` (
  `msg_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '消息标识',
  `msg_type_id` int(11) NOT NULL COMMENT '消息类型id',
  `msg_sender_id` int(11) NOT NULL COMMENT '消息发送人',
  `msg_receiver_id` int(11) NOT NULL COMMENT '接收人',
  `msg_content` varchar(200) CHARACTER SET utf8mb4 NOT NULL COMMENT '消息内容',
  `msg_pic_ids` text,
  `msg_send_datetime` datetime NOT NULL COMMENT '消息发送时间',
  `msg_state` smallint(6) DEFAULT '0' COMMENT '未读 1  已读 : 0',
  `msg_obj_id` bigint(20) DEFAULT NULL COMMENT '本身ID(如果是话题跟帖/点赞，这里就是跟帖/点赞的ID，如果是跟帖的回复/点赞，这里就是回复/点赞的ID)',
  `msg_target_id` bigint(20) DEFAULT NULL COMMENT '目标ID(如果是话题跟帖/点赞，这里就是话题的ID，如果是跟帖的回复/点赞，这里就是跟帖ID)',
  `msg_target_type` smallint(6) DEFAULT NULL COMMENT '对目标的操作类型:(回复:0 点赞:1 圈子申请加入：2 圈子审核通过：3 圈子拒绝：4)',
  PRIMARY KEY (`msg_id`),
  KEY `IX_MSG_receiver` (`msg_receiver_id`),
  KEY `IX_MSG_SEND_DT` (`msg_send_datetime`)
) ENGINE=InnoDB AUTO_INCREMENT=1747143 DEFAULT CHARSET=utf8;

CREATE TABLE `mbss_account_point` (
  `account_point_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `account_id` bigint(20) NOT NULL COMMENT '用户id',
  `points_code` varchar(30) NOT NULL COMMENT '积分编码',
  `point` int(11) NOT NULL COMMENT '积分',
  `created_date` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`account_point_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11247 DEFAULT CHARSET=utf8mb4 COMMENT='会员积分明显表';

CREATE TABLE `mbss_account_qq_info` (
  `account_id` smallint(6) NOT NULL,
  `nickname` varchar(128) NOT NULL COMMENT '昵称',
  `gender` varchar(2) DEFAULT NULL COMMENT '性别',
  `province` varchar(20) DEFAULT NULL COMMENT '省',
  `city` varchar(20) DEFAULT NULL COMMENT '市',
  `figureurl` varchar(128) DEFAULT NULL COMMENT '头像',
  `qq_level` varchar(10) DEFAULT NULL COMMENT 'qq等级',
  `qq_vip_level` varchar(10) DEFAULT NULL COMMENT 'qq会员等级',
  `is_yellow_vip` varchar(10) DEFAULT NULL COMMENT '是否为黄钻用户',
  `is_yellow_year_vip` varchar(10) DEFAULT NULL COMMENT '是否为年费黄钻用户',
  `yellow_vip_level` varchar(10) DEFAULT NULL COMMENT '黄钻等级',
  `ret` varchar(128) DEFAULT NULL COMMENT '返回码',
  `is_lost` smallint(6) DEFAULT NULL COMMENT '判断是否有数据丢失',
  `figureurl_1` varchar(128) DEFAULT NULL COMMENT 'qq空间url1',
  `figureurl_2` varchar(128) DEFAULT NULL COMMENT 'qq空间url2',
  `figureurl_qq_1` varchar(128) DEFAULT NULL COMMENT 'qq头像1',
  `figureurl_qq_2` varchar(128) DEFAULT NULL COMMENT 'qq头像2',
  `msg` varchar(128) DEFAULT NULL COMMENT '错误信息',
  `device_id` varchar(128) DEFAULT NULL COMMENT '设备ID',
  `device_name` varchar(64) DEFAULT NULL COMMENT '设备名称',
  `is_delete` smallint(6) DEFAULT NULL COMMENT '是否删除 (1：删除)',
  `created_datetime` datetime DEFAULT NULL,
  `updated_datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`account_id`),
  UNIQUE KEY `IX_QQ_ACCOUNTID` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `mbss_account_sn_account` (
  `account_id` int(11) NOT NULL COMMENT '帐号ID',
  `sn_id` varchar(128) NOT NULL COMMENT '易购帐号Id',
  PRIMARY KEY (`account_id`),
  UNIQUE KEY `IX_ACCOUNT_SN_ACCOUNT_SN_ID` (`sn_id`) USING HASH
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `mbss_account_third_part` (
  `account_id` int(11) NOT NULL COMMENT '帐号ID',
  `thirdpart_type` smallint(6) NOT NULL COMMENT '第三方类型',
  `open_id` varchar(128) NOT NULL COMMENT '第三方OpenId',
  `access_token` varchar(256) DEFAULT NULL COMMENT '第三方访问标识',
  `token_created_dt` datetime DEFAULT NULL COMMENT '第三方accesstoken创建时间',
  `token_access_datetime` datetime DEFAULT NULL COMMENT 'token获取时间',
  PRIMARY KEY (`account_id`,`thirdpart_type`),
  UNIQUE KEY `IX_ACCOUNT_THIRD_PART_OPENID` (`open_id`) USING HASH
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `mbss_ad` (
  `ad_id` int(11) NOT NULL COMMENT 'ID',
  `ad_name` varchar(200) NOT NULL COMMENT '广告',
  `ad_type` smallint(6) DEFAULT NULL COMMENT '广告类型(1：消息，2：宝宝秀)',
  `pic_path` varchar(100) NOT NULL COMMENT '图片路径',
  `url` varchar(200) NOT NULL COMMENT 'url链接',
  `url_type` smallint(6) DEFAULT NULL COMMENT '1:外部链接  2:内部页面  3:圈子  4:话题  5:跟帖',
  `state` smallint(6) DEFAULT NULL,
  `creator` int(11) NOT NULL COMMENT '上传人',
  `created_datetime` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_id` int(11) DEFAULT NULL COMMENT '修改人ID',
  `modify_datetime` datetime DEFAULT NULL COMMENT '最后修改日期',
  `logo_url` varchar(200) DEFAULT NULL COMMENT 'logo图片路径',
  `ad_content` varchar(400) DEFAULT NULL COMMENT '广告内容',
  `android_version` varchar(20) DEFAULT NULL COMMENT '安卓版本以上显示',
  `ios_version` varchar(20) DEFAULT NULL COMMENT 'ios版本 以上显示',
  PRIMARY KEY (`ad_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `mbss_album_album_template` (
  `album_id` bigint(20) NOT NULL COMMENT '影集Id',
  `tpl_id` int(11) NOT NULL COMMENT '影集模板',
  `album_comment` varchar(280) DEFAULT NULL COMMENT '影集描述',
  PRIMARY KEY (`album_id`,`tpl_id`),
  KEY `IX_ALBUM_TPL_ID` (`tpl_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `mbss_album_item` (
  `item_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '影集项id',
  `album_id` bigint(20) NOT NULL COMMENT '影集Id',
  `item_url` varchar(200) NOT NULL COMMENT '影集项地址',
  `item_content` varchar(280) CHARACTER SET utf8mb4 NOT NULL COMMENT '影集项内容',
  `item_order` bigint(20) NOT NULL COMMENT '影集项顺序',
  PRIMARY KEY (`item_id`),
  KEY `album_item_inx1` (`album_id`),
  KEY `album_item_inx2` (`item_url`)
) ENGINE=InnoDB AUTO_INCREMENT=128857 DEFAULT CHARSET=utf8;

CREATE TABLE `mbss_album_template` (
  `tpl_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '模版Id',
  `tpl_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模版名称',
  `tpl_view_url` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '模版预览地址',
  `tpl_download_url` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模板下载地址',
  `tpl_pic_num` smallint(6) NOT NULL COMMENT '模版图片数量',
  `tpl_pic_min` smallint(6) DEFAULT NULL COMMENT '图片最少数量',
  `tpl_comment` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '模版备注',
  `tpl_share_content` varchar(256) DEFAULT NULL COMMENT '默认分享内容',
  `tpl_order` int(11) DEFAULT NULL COMMENT '模板顺序',
  `tpl_state` smallint(6) NOT NULL COMMENT '模版状态',
  `tpl_v_cnt` int(11) DEFAULT NULL COMMENT '虚拟人数',
  `creator` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模版上传人',
  `created_datetime` datetime NOT NULL COMMENT '模版创建时间',
  `modify_id` int(11) DEFAULT NULL COMMENT '修改人ID',
  `modify_datetime` datetime DEFAULT NULL COMMENT '最后修改日期',
  PRIMARY KEY (`tpl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

CREATE TABLE `mbss_baby` (
  `baby_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '宝宝ID',
  `baby_name` varchar(20) NOT NULL COMMENT '昵称',
  `family_id` int(11) NOT NULL COMMENT '家庭ID',
  `birthday` date NOT NULL COMMENT '宝宝出生年月日',
  `baby_sex` tinyint(4) NOT NULL COMMENT '宝宝性别',
  `constellation` varchar(8) NOT NULL COMMENT '宝宝星座',
  `icon_url` varchar(256) DEFAULT NULL COMMENT '宝宝头像Url',
  `created_datetime` datetime NOT NULL COMMENT '宝宝创建日期',
  PRIMARY KEY (`baby_id`),
  UNIQUE KEY `IX_BABY_BID` (`baby_id`),
  KEY `IX_BABY_FAM` (`family_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1148 DEFAULT CHARSET=utf8;

CREATE TABLE `mbss_channel_package` (
  `package_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `package_name` varchar(200) NOT NULL COMMENT '渠道名称',
  `url` varchar(200) DEFAULT NULL COMMENT 'url',
  `memo` varchar(200) DEFAULT NULL COMMENT '备注',
  `is_default_package` smallint(6) DEFAULT NULL COMMENT '是否默认渠道包 （0：非默认，1：默认）',
  `qrc_url` varchar(200) DEFAULT NULL COMMENT '二维码图片url',
  `state` smallint(6) DEFAULT NULL COMMENT '0:未启用 1:启用',
  `creator` int(11) NOT NULL COMMENT '上传人',
  `created_datetime` datetime NOT NULL COMMENT '创建时间',
  `modify_id` int(11) DEFAULT NULL COMMENT '修改人ID',
  `modify_datetime` datetime DEFAULT NULL COMMENT '最后修改日期',
  PRIMARY KEY (`package_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4;

CREATE TABLE `mbss_circle` (
  `circle_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '圈子ID',
  `circle_name` varchar(50) NOT NULL COMMENT '圈子名称',
  `circle_type` smallint(6) NOT NULL COMMENT '圈子类型：1，平台，2：私密 3：半公开',
  `circle_admin` bigint(20) NOT NULL COMMENT '圈主',
  `circle_memo` varchar(240) DEFAULT NULL COMMENT '圈子简介',
  `circle_order` smallint(6) DEFAULT '0' COMMENT '展示顺序',
  `circle_member_cnt` int(11) DEFAULT '0' COMMENT '成员人数',
  `circle_title_cnt` int(11) DEFAULT '0' COMMENT '话题数量',
  `is_default_show` smallint(6) DEFAULT '0' COMMENT '是否默认展示 0：不展示  1：展示',
  `state` smallint(6) DEFAULT '0' COMMENT '状态(0:停用 1:启用)',
  `creator` bigint(20) DEFAULT NULL COMMENT '创建人',
  `created_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modifier` bigint(20) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  `create_type` int(11) DEFAULT NULL COMMENT '创建方式 (1:前台 2:后台)',
  PRIMARY KEY (`circle_id`),
  KEY `idx_mbss_circle_circle_admin` (`circle_admin`),
  FULLTEXT KEY `idx_mbss_circle_circle_name` (`circle_name`)
) ENGINE=MyISAM AUTO_INCREMENT=307 DEFAULT CHARSET=utf8mb4 COMMENT='圈子表';

CREATE TABLE `mbss_circle_approval` (
  `approval_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '审核id',
  `account_id` bigint(20) NOT NULL COMMENT '申请用户id',
  `circle_id` bigint(20) NOT NULL COMMENT '圈子ID',
  `cir_account_id` bigint(20) DEFAULT NULL COMMENT '圈主id',
  `approval_content` varchar(200) DEFAULT NULL COMMENT '申请留言',
  `state` smallint(6) DEFAULT NULL COMMENT '申请状态（0:删除  1:审核中  2:同意  3:拒绝）',
  `join_datetime` datetime DEFAULT NULL COMMENT '申请加入时间',
  `approval_datetime` datetime DEFAULT NULL COMMENT '审批时间',
  PRIMARY KEY (`approval_id`),
  KEY `idx_approval_account_id` (`account_id`),
  KEY `idx_approval_circle_id` (`circle_id`),
  KEY `idx_approval_ciraccount_id` (`cir_account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=182 DEFAULT CHARSET=utf8mb4 COMMENT='圈子审核表';

CREATE TABLE `mbss_circle_exit` (
  `account_id` bigint(20) NOT NULL,
  `circle_id` bigint(20) NOT NULL,
  `exit_datetime` datetime NOT NULL,
  PRIMARY KEY (`account_id`,`circle_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `mbss_circle_invite` (
  `join_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '邀请ID',
  `circle_id` bigint(20) NOT NULL COMMENT '圈子ID',
  `join_url` varchar(256) NOT NULL COMMENT '邀请路径',
  `joined_num` int(11) NOT NULL COMMENT '已加入次数',
  `invited_datetime` datetime NOT NULL COMMENT '邀请时间',
  `join_type` smallint(6) DEFAULT NULL COMMENT '邀请类型(1:圈子   待扩展)',
  PRIMARY KEY (`join_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `mbss_college` (
  `col_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '学校ID',
  `col_name` varchar(100) NOT NULL COMMENT '名称',
  `dept` varchar(50) DEFAULT NULL COMMENT '专业',
  `max_score` int(11) DEFAULT NULL COMMENT '最高分数',
  `min_score` int(11) DEFAULT NULL COMMENT '最低分数',
  PRIMARY KEY (`col_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15516 DEFAULT CHARSET=utf8mb4 COMMENT='学校表';

CREATE TABLE `mbss_diary_comment` (
  `comment_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '评论ID',
  `diary_id` bigint(20) NOT NULL COMMENT '日记ID',
  `comment_person` int(11) NOT NULL COMMENT '评论人',
  `comment_datetime` datetime NOT NULL COMMENT '评论时间',
  `comment_content` varchar(200) NOT NULL COMMENT '评论内容',
  `reply_to_person` int(11) DEFAULT NULL COMMENT '回复谁',
  PRIMARY KEY (`comment_id`),
  KEY `IX_DIARY_CMT_DIARYID` (`diary_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1142 DEFAULT CHARSET=utf8mb4;

CREATE TABLE `mbss_family` (
  `family_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '家庭ID',
  `family_name` varchar(20) NOT NULL COMMENT '家庭名称',
  `creator_id` int(11) NOT NULL COMMENT '家庭创建人',
  `created_datetime` datetime NOT NULL COMMENT '家庭创建时间',
  `used_space` bigint(20) NOT NULL DEFAULT '0' COMMENT '家庭空间使用大小',
  `family_icon_url` varchar(256) DEFAULT NULL COMMENT '家庭头像地址',
  `flag_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否已删除',
  PRIMARY KEY (`family_id`)
) ENGINE=InnoDB AUTO_INCREMENT=963 DEFAULT CHARSET=utf8;

CREATE TABLE `mbss_family_member` (
  `member_id` int(11) NOT NULL COMMENT '家庭成员ID',
  `family_id` int(11) NOT NULL COMMENT '家庭ID',
  `role_name` varchar(10) NOT NULL COMMENT '家庭成员角色名称',
  `upload_auth` tinyint(4) NOT NULL COMMENT '家庭成员上传权限',
  `join_type` smallint(6) NOT NULL COMMENT '家庭成员加入方式',
  `join_datetime` datetime NOT NULL COMMENT '家庭成员加入时间',
  PRIMARY KEY (`member_id`,`family_id`),
  KEY `IX_FM` (`member_id`,`family_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `mbss_file` (
  `file_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `file_url` varchar(200) NOT NULL COMMENT '文件路径',
  `store_type` tinyint(4) NOT NULL DEFAULT '0',
  `file_sal_request_id` varchar(200) DEFAULT NULL COMMENT '文件SAL请求ID',
  `file_sal_object_id` varchar(200) DEFAULT NULL COMMENT '文件SAL对象ID',
  `file_uimg_id` varchar(64) DEFAULT NULL,
  `file_size` bigint(20) NOT NULL COMMENT '文件大小',
  `file_upload_success` tinyint(4) DEFAULT NULL COMMENT '上传是否成功',
  `deleted_flag` tinyint(4) DEFAULT NULL COMMENT '是否删除',
  `file_name` varchar(200) NOT NULL,
  PRIMARY KEY (`file_id`),
  UNIQUE KEY `IX_FILE_sal_request_id` (`file_sal_request_id`) USING BTREE,
  KEY `IX_FILE_file_url` (`file_url`)
) ENGINE=InnoDB AUTO_INCREMENT=217724 DEFAULT CHARSET=utf8;

CREATE TABLE `mbss_grown_diary` (
  `diary_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '成长日记ID',
  `family_id` int(11) NOT NULL COMMENT '家庭ID',
  `diary_content` varchar(560) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '成长内容',
  `diary_date` date NOT NULL COMMENT '成长日记时间',
  `short_url` varchar(50) DEFAULT NULL COMMENT '分享短链',
  `creator_id` int(11) NOT NULL COMMENT '成长日记创建者',
  `created_datetime` datetime NOT NULL COMMENT '成长日记创建时间',
  `update_person` int(11) DEFAULT NULL COMMENT '成长日记更新人',
  `update_datetime` datetime DEFAULT NULL COMMENT '成长日记更新时间',
  PRIMARY KEY (`diary_id`),
  KEY `diary_inx1` (`family_id`),
  KEY `diary_inx2` (`diary_date`)
) ENGINE=InnoDB AUTO_INCREMENT=2234 DEFAULT CHARSET=utf8;

CREATE TABLE `mbss_html_page` (
  `html_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '静态页面id',
  `html_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '页面名称',
  `html_path` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '页面地址',
  `package_path` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '包路径',
  `creator` bigint(20) DEFAULT NULL COMMENT '创建人',
  `created_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modifier` bigint(20) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`html_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COMMENT='静态页面表';

CREATE TABLE `mbss_illegal_words` (
  `illegal_word` varchar(30) NOT NULL COMMENT '敏感词'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='敏感词表';

CREATE TABLE `mbss_invite` (
  `join_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '邀请ID',
  `family_id` int(11) NOT NULL COMMENT '家庭ID',
  `join_url` varchar(256) NOT NULL COMMENT '邀请路径',
  `joined_num` int(11) NOT NULL COMMENT '已加入次数',
  `invited_datetime` datetime NOT NULL COMMENT '邀请时间',
  PRIMARY KEY (`join_id`),
  KEY `IX_INVITE_join_url` (`join_url`(255))
) ENGINE=InnoDB AUTO_INCREMENT=3128 DEFAULT CHARSET=utf8;

CREATE TABLE `mbss_jewel_box` (
  `box_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '百宝箱ID',
  `box_name` varchar(30) NOT NULL COMMENT '模块名称',
  `box_url` varchar(100) DEFAULT NULL COMMENT '缩略图url',
  `box_order` smallint(6) DEFAULT NULL COMMENT '展示顺序',
  `box_address` varchar(100) DEFAULT NULL COMMENT '关联地址',
  `box_type` smallint(6) DEFAULT NULL COMMENT '百宝箱类型：1：外部地址，2：内部页面',
  `tag_img_url` varchar(100) DEFAULT NULL COMMENT '标签图url',
  `state` smallint(6) DEFAULT NULL COMMENT '状态',
  `creator` bigint(20) DEFAULT NULL COMMENT '创建人',
  `created_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modifier` bigint(20) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  `android_version` varchar(20) DEFAULT NULL COMMENT '安卓版本以上显示',
  `ios_version` varchar(20) DEFAULT NULL COMMENT 'ios版本 以上显示',
  PRIMARY KEY (`box_id`),
  KEY `idx_jewel_box_name` (`box_name`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8mb4 COMMENT='百宝箱表';

CREATE TABLE `mbss_message` (
  `msg_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '消息标识',
  `msg_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '消息名称',
  `msg_content` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '消息内容',
  `url_type` smallint(6) DEFAULT NULL,
  `msg_url` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '消息url',
  `msg_state` int(11) NOT NULL COMMENT '消息状态',
  `pushed_device` int(11) NOT NULL COMMENT '推送到设备',
  `msg_comment` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '消息备注',
  `creator_id` int(11) NOT NULL COMMENT '消息上传人',
  `created_datetime` datetime NOT NULL COMMENT '消息发布时间',
  `modify_id` int(11) DEFAULT NULL COMMENT '修改人ID',
  `modify_datetime` datetime DEFAULT NULL COMMENT '最后修改日期',
  PRIMARY KEY (`msg_id`)
) ENGINE=InnoDB AUTO_INCREMENT=389 DEFAULT CHARSET=utf8mb4;

CREATE TABLE `mbss_message_queue` (
  `queue_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增队列',
  `msg_id` int(11) NOT NULL COMMENT '消息类型id',
  `msg_receiver_id` int(11) NOT NULL COMMENT '接收人',
  `msg_start_datetime` datetime DEFAULT NULL COMMENT '消息下发时间',
  `msg_send_datetime` datetime DEFAULT NULL COMMENT '消息发送时间',
  `msg_state` int(11) NOT NULL COMMENT '消息状态',
  PRIMARY KEY (`queue_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28509 DEFAULT CHARSET=utf8mb4;

CREATE TABLE `mbss_msg_type` (
  `msg_type_id` int(11) NOT NULL COMMENT '消息类型ID',
  `msg_type_name` varchar(10) NOT NULL COMMENT '消息类型名称',
  PRIMARY KEY (`msg_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `mbss_mycircle` (
  `mycir_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '我的圈子id',
  `account_id` bigint(20) NOT NULL COMMENT '用户ID',
  `circle_id` bigint(20) NOT NULL COMMENT '圈子ID',
  `join_datetime` datetime DEFAULT NULL COMMENT '加入时间',
  `exit_datetime` datetime DEFAULT NULL COMMENT '退出时间',
  `update_cnt` int(11) DEFAULT NULL COMMENT '更新数',
  PRIMARY KEY (`mycir_id`),
  UNIQUE KEY `IX_MY_CIRCLE` (`account_id`,`circle_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1531 DEFAULT CHARSET=utf8mb4 COMMENT='我的圈子表';

CREATE TABLE `mbss_picture` (
  `pic_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '图片ID',
  `pic_type` smallint(6) NOT NULL COMMENT '图片类型',
  `pic_comment` varchar(560) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '图片文字',
  `family_id` int(11) NOT NULL COMMENT '家庭ID',
  `pic_date` date DEFAULT NULL,
  `pic_datetime` datetime NOT NULL COMMENT '图片拍摄时间',
  `rpic_url` varchar(200) NOT NULL COMMENT '原图路径',
  `thubmnail_url` varchar(200) DEFAULT NULL COMMENT '缩略图地址',
  `cpic_url` varchar(200) DEFAULT NULL COMMENT '压缩图地址',
  `pic_width` int(11) DEFAULT NULL COMMENT '图片宽度像素',
  `pic_height` int(11) DEFAULT NULL COMMENT '图片长度像素',
  `is_thumbs` smallint(6) DEFAULT NULL COMMENT '是否压缩 (0：未压缩，1：压缩)',
  `pic_deleted` tinyint(4) NOT NULL COMMENT '已删除',
  `creator_id` int(11) DEFAULT NULL COMMENT '上传人',
  `created_datetime` datetime NOT NULL COMMENT '上传时间',
  `modify_person` int(11) DEFAULT NULL COMMENT '相片更新人',
  `modify_datetime` datetime DEFAULT NULL COMMENT '相片更新时间',
  PRIMARY KEY (`pic_id`),
  KEY `IX_PIC_family_id` (`family_id`) USING BTREE,
  KEY `IX_PIC_FAM_CREATOR` (`family_id`,`creator_id`),
  KEY `IX_PIC_CREATOR` (`creator_id`),
  KEY `IX_PIC_F_C_P` (`family_id`,`creator_id`,`pic_type`),
  KEY `IX_PIC_DT` (`pic_datetime`),
  KEY `IX_PIC_D_T_F_DT` (`pic_deleted`,`pic_type`,`family_id`,`pic_date`) USING BTREE,
  KEY `IX_PIC_R` (`rpic_url`)
) ENGINE=InnoDB AUTO_INCREMENT=167717 DEFAULT CHARSET=utf8;

CREATE TABLE `mbss_picture_aggregation` (
  `pic_id` bigint(20) NOT NULL COMMENT '图片ID',
  `comment_count` int(11) NOT NULL COMMENT '图片评论数',
  PRIMARY KEY (`pic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE `mbss_picture_comment` (
  `comment_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '评论ID',
  `pic_id` bigint(20) NOT NULL COMMENT '图片ID',
  `comment_person` int(11) NOT NULL COMMENT '评论人',
  `comment_datetime` datetime NOT NULL COMMENT '评论时间',
  `comment_content` text CHARACTER SET utf8mb4,
  `reply_to_person` int(11) DEFAULT NULL COMMENT '回复谁',
  PRIMARY KEY (`comment_id`),
  KEY `IX_COMMENT_pic_id` (`pic_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=980948 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE `mbss_picture_favor` (
  `fav_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '收藏ID',
  `pic_id` bigint(20) NOT NULL COMMENT '相片ID',
  `pic_type` smallint(6) NOT NULL COMMENT '相片类型',
  `family_id` int(11) NOT NULL COMMENT '家庭ID',
  `fav_account_id` int(11) NOT NULL COMMENT '收藏人ID',
  `fav_datetime` datetime NOT NULL COMMENT '收藏时间',
  PRIMARY KEY (`fav_id`),
  UNIQUE KEY `IX_FAVOR_PIC_ACC` (`pic_id`,`fav_account_id`) USING HASH
) ENGINE=InnoDB AUTO_INCREMENT=4464771 DEFAULT CHARSET=utf8;

CREATE TABLE `mbss_points` (
  `points_id` int(11) NOT NULL COMMENT 'id',
  `points_code` varchar(30) NOT NULL COMMENT '积分编码',
  `points_name` varchar(30) NOT NULL COMMENT '积分项目',
  `point` int(11) NOT NULL COMMENT '积分',
  `creator` bigint(20) DEFAULT NULL COMMENT '创建人',
  `created_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modifier` bigint(20) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  `limit_num_daily` int(11) DEFAULT '0' COMMENT '每天限制次数',
  `limit_num_total` int(11) DEFAULT '0' COMMENT '限制总次数',
  PRIMARY KEY (`points_id`),
  UNIQUE KEY `points_name_UNIQUE` (`points_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='积分规则表';

CREATE TABLE `mbss_praise` (
  `praise_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '点赞id',
  `account_id` bigint(20) NOT NULL COMMENT '用户ID',
  `obj_id` bigint(20) NOT NULL COMMENT '对象id',
  `obj_type` smallint(6) DEFAULT NULL COMMENT '类型（1:圈子id  2:话题id 3::跟帖）',
  `created_date` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`praise_id`),
  UNIQUE KEY `idx_praise_account_obj_type` (`account_id`,`obj_id`,`obj_type`)
) ENGINE=InnoDB AUTO_INCREMENT=2485 DEFAULT CHARSET=utf8mb4 COMMENT='点赞表';

CREATE TABLE `mbss_rank` (
  `rank_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `rank_name` varchar(30) NOT NULL COMMENT '等级名称',
  `lowest_score` int(11) DEFAULT '0' COMMENT '最低分',
  `highest_score` int(11) DEFAULT '0' COMMENT '最高分',
  `creator` bigint(20) DEFAULT NULL COMMENT '创建人',
  `created_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modifier` bigint(20) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`rank_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COMMENT='会员等级表';

CREATE TABLE `mbss_reply` (
  `reply_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '跟帖ID',
  `topic_id` bigint(20) NOT NULL COMMENT '话题ID',
  `reply_content` text NOT NULL COMMENT '内容',
  `reply_comment_cnt` int(11) NOT NULL DEFAULT '0' COMMENT '评论数量',
  `reply_praise_cnt` int(11) DEFAULT '0' COMMENT '点赞数量',
  `state` smallint(6) DEFAULT NULL COMMENT '状态(0:停用 1:启用)',
  `creator` bigint(20) DEFAULT NULL COMMENT '创建人',
  `created_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modifier` bigint(20) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`reply_id`),
  KEY `idx_reply_topic_id` (`topic_id`),
  KEY `idx_reply_creator` (`creator`)
) ENGINE=MyISAM AUTO_INCREMENT=1131 DEFAULT CHARSET=utf8mb4 COMMENT='跟帖表';

CREATE TABLE `mbss_reply_comment` (
  `comment_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '评论ID',
  `reply_id` bigint(20) NOT NULL COMMENT '跟帖ID',
  `comment_person` bigint(20) NOT NULL COMMENT '评论人',
  `comment_datetime` datetime NOT NULL COMMENT '评论时间',
  `comment_content` varchar(200) NOT NULL COMMENT '评论内容',
  `reply_to_person` bigint(20) DEFAULT NULL COMMENT '回复谁',
  `state` smallint(6) DEFAULT NULL COMMENT '状态(0:停用 1:启用)',
  PRIMARY KEY (`comment_id`),
  KEY `idx_reply_cmt_reply_id` (`reply_id`) USING BTREE,
  KEY `idx_reply_cmt_person` (`comment_person`)
) ENGINE=MyISAM AUTO_INCREMENT=913 DEFAULT CHARSET=utf8mb4;

CREATE TABLE `mbss_report` (
  `report_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '举报ID',
  `pic_id` bigint(20) NOT NULL COMMENT '资源id',
  `pic_type` smallint(6) NOT NULL COMMENT '资源类型(1:普通图片，2：宝宝秀，3：影集)',
  `pic_content` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '举报内容',
  `account_id` bigint(20) NOT NULL COMMENT '举报人id',
  `report_time` datetime NOT NULL COMMENT '举报时间',
  `deal_account_id` bigint(20) DEFAULT NULL COMMENT '处理人',
  `deal_time` datetime DEFAULT NULL COMMENT '处理时间',
  `state` smallint(6) DEFAULT '0' COMMENT '状态 默认0，1：审核通过，2：审核未通过',
  PRIMARY KEY (`report_id`),
  KEY `IX_REPORT_PICID` (`pic_id`),
  KEY `IX_REPORT_ACCOUNTID` (`account_id`) USING BTREE,
  KEY `IX_REPORT_TIME` (`report_time`)
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8mb4;

CREATE TABLE `mbss_share` (
  `share_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '分享ID',
  `share_channel` int(11) NOT NULL COMMENT '分享渠道',
  `share_url` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '分享地址',
  `share_res_id` bigint(20) NOT NULL COMMENT '分享资源ID',
  `share_type` smallint(6) DEFAULT '0' COMMENT '分享类型 0:图片，1：日记',
  `share_person_id` int(11) NOT NULL COMMENT '分享人',
  `share_datetime` datetime NOT NULL COMMENT '分享时间',
  `share_state` smallint(6) NOT NULL DEFAULT '1' COMMENT '分享状态',
  PRIMARY KEY (`share_id`),
  KEY `ix_share_res_id` (`share_res_id`)
) ENGINE=InnoDB AUTO_INCREMENT=804 DEFAULT CHARSET=utf8mb4;

CREATE TABLE `mbss_share_compare` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_Id` int(11) NOT NULL COMMENT '发布擂台用户ID',
  `nickname` varchar(50) DEFAULT NULL COMMENT '昵称',
  `compare_Id` int(11) DEFAULT NULL COMMENT '配对用户ID',
  `type` smallint(2) DEFAULT '1' COMMENT '1：擂台还是 2：配对',
  `uimage_id` varchar(255) DEFAULT NULL COMMENT '宝宝图片存放的UimageId',
  `baby_img_url` varchar(255) DEFAULT NULL,
  `faceId` varchar(255) DEFAULT NULL COMMENT 'Face++的图片ID',
  `score` int(11) DEFAULT '90' COMMENT '宝宝评测分数',
  `compare_index` int(11) DEFAULT '90' COMMENT '配对指数',
  `mark` varchar(1000) DEFAULT NULL COMMENT '描述',
  `coupon_1` varchar(1000) DEFAULT NULL COMMENT '优惠券',
  `coupon_2` varchar(1000) DEFAULT NULL COMMENT '优惠券',
  `baby_sex` varchar(10) DEFAULT '男' COMMENT '宝宝性别',
  `baby_age` varchar(20) DEFAULT NULL COMMENT '宝宝年龄',
  PRIMARY KEY (`id`),
  KEY `idx_share_cmp_account_id` (`account_Id`),
  KEY `idx_share_cmp_nickname` (`nickname`),
  KEY `idx_share_cmp_cmp_id` (`compare_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

CREATE TABLE `mbss_share_content_tpl` (
  `share_tpl_id` varchar(200) NOT NULL COMMENT '分享模版ID',
  `share_tpl_content` varchar(280) NOT NULL COMMENT '分享模版内容',
  `creator_id` int(11) NOT NULL COMMENT '创建人ID',
  `created_datetime` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`share_tpl_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `mbss_share_question` (
  `question_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '题目Id',
  `question_name` varchar(50) NOT NULL COMMENT '题目名称',
  `answer_a` varchar(50) NOT NULL COMMENT '答案A',
  `answer_b` varchar(50) NOT NULL COMMENT '答案B',
  `answer_c` varchar(50) DEFAULT NULL COMMENT '答案C',
  `answer_d` varchar(50) DEFAULT NULL COMMENT '答案D',
  `answer_right` char(1) NOT NULL DEFAULT 'A' COMMENT '题目正确答案默认A',
  `question_score` int(11) NOT NULL DEFAULT '20' COMMENT '题目分数',
  `answer_explain` varchar(1000) DEFAULT NULL COMMENT '答案的解释',
  PRIMARY KEY (`question_id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4;

CREATE TABLE `mbss_share_score` (
  `score_id` int(11) NOT NULL AUTO_INCREMENT,
  `score_min` int(11) NOT NULL COMMENT '分数段最低分',
  `score_max` int(11) NOT NULL COMMENT '分数段最高分',
  `score_explan` varchar(1000) DEFAULT NULL COMMENT '分数对应的评语',
  PRIMARY KEY (`score_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

CREATE TABLE `mbss_stu_col` (
  `stu_id` int(11) NOT NULL COMMENT '学生ID',
  `col_id` int(11) NOT NULL COMMENT '学校ID',
  `stu_name` varchar(50) NOT NULL COMMENT '姓名',
  PRIMARY KEY (`stu_id`,`col_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `mbss_student` (
  `stu_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '学生ID',
  `stu_name` varchar(50) NOT NULL COMMENT '姓名',
  `stu_score` int(11) DEFAULT NULL COMMENT '分数',
  `creator` int(11) DEFAULT NULL COMMENT '创建人',
  `created_datetime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`stu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=222 DEFAULT CHARSET=utf8mb4 COMMENT='学生表';

CREATE TABLE `mbss_suggestion` (
  `sug_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '意见ID',
  `sug_account_id` int(11) NOT NULL COMMENT '建议人',
  `sug_content` text CHARACTER SET utf8mb4 NOT NULL COMMENT '意见内容',
  `contact_no` varchar(60) DEFAULT NULL COMMENT '联系方式',
  `app_version` varchar(10) DEFAULT NULL COMMENT 'app当前版本',
  `os_version` varchar(50) DEFAULT NULL COMMENT '手机操作系统版本',
  `device_mode` varchar(50) DEFAULT NULL COMMENT '设备号',
  `created_datetime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`sug_id`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8;

CREATE TABLE `mbss_sys_config` (
  `cfg_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `cfg_key` varchar(50) NOT NULL COMMENT '配置项KEY',
  `cfg_value` varchar(200) NOT NULL COMMENT '配置项值',
  `cfg_type` smallint(2) DEFAULT '0',
  `cfg_remark` varchar(20) DEFAULT NULL COMMENT '配置项说明',
  `cfg_creator` varchar(20) NOT NULL COMMENT '配置项创建人',
  `created_datetime` datetime NOT NULL COMMENT '配置项创建时间',
  `modify_person` varchar(20) DEFAULT NULL COMMENT '配置项修改人',
  `modify_datetime` datetime DEFAULT NULL COMMENT '配置项修改时间',
  PRIMARY KEY (`cfg_id`),
  UNIQUE KEY `IX_SYS_CONFIG_CFG` (`cfg_key`) USING HASH
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

CREATE TABLE `mbss_sys_role` (
  `role_id` int(11) NOT NULL COMMENT '角色ID',
  `role_name` varchar(10) NOT NULL COMMENT '角色名称',
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `mbss_sys_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `user_name` varchar(20) NOT NULL COMMENT '用户名',
  `password` varchar(32) NOT NULL COMMENT '密码',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

CREATE TABLE `mbss_sys_user_role` (
  `user_id` int(11) NOT NULL COMMENT '用户id',
  `role_id` int(11) NOT NULL COMMENT '角色id',
  PRIMARY KEY (`user_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `mbss_topic` (
  `topic_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '话题ID',
  `circle_id` bigint(20) DEFAULT NULL COMMENT '圈子id',
  `topic_title` varchar(50) NOT NULL COMMENT '标题',
  `topic_content` text NOT NULL COMMENT '内容',
  `topic_type` smallint(6) DEFAULT NULL COMMENT '话题类型(1: 活动   2:普通  )',
  `topic_is_top` smallint(6) DEFAULT NULL COMMENT '是否置顶',
  `topic_is_good` smallint(6) DEFAULT NULL COMMENT '是否加精',
  `topic_reply_cnt` int(11) NOT NULL DEFAULT '0' COMMENT '跟帖数量',
  `topic_praise_cnt` int(11) DEFAULT '0' COMMENT '关注人数',
  `topic_click_cnt` int(11) DEFAULT '0' COMMENT '点击量',
  `state` smallint(6) DEFAULT NULL COMMENT '状态(0:停用 1:启用)',
  `creator` bigint(20) DEFAULT NULL COMMENT '创建人',
  `created_date` datetime DEFAULT NULL COMMENT '创建时间',
  `modifier` bigint(20) DEFAULT NULL COMMENT '修改人',
  `modify_date` datetime DEFAULT NULL COMMENT '修改时间',
  `last_modifier` bigint(20) DEFAULT NULL COMMENT '最后修改人',
  `last_modify_date` datetime DEFAULT NULL COMMENT '最后修改时间',
  PRIMARY KEY (`topic_id`),
  KEY `idx_topic_circle_id` (`circle_id`),
  KEY `idx_topic_creator` (`creator`)
) ENGINE=MyISAM AUTO_INCREMENT=708 DEFAULT CHARSET=utf8mb4 COMMENT='话题表';

CREATE TABLE `mbss_topic_pic` (
  `top_pic_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `pic_id` bigint(20) DEFAULT NULL COMMENT '图片id 或 图片url',
  `pic_url` varchar(100) DEFAULT NULL COMMENT '图片url',
  `obj_id` bigint(20) NOT NULL COMMENT '对象id',
  `obj_type` smallint(6) DEFAULT NULL COMMENT '类型（1:圈子id  2:话题id 3::跟帖）',
  `store_type` smallint(6) DEFAULT NULL COMMENT '存储位置(1:sal   2: uimg)',
  PRIMARY KEY (`top_pic_id`),
  KEY `idx_topic_pic_id_type` (`obj_id`,`obj_type`),
  KEY `idx_topic_pic_pic_id` (`pic_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1307 DEFAULT CHARSET=utf8mb4 COMMENT='主题图片关联表';

CREATE TABLE `mbss_version` (
  `version_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '版本自增',
  `version_no` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '版本号',
  `version_name` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '版本名称',
  `version_desc` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '版本描述',
  `version_type` smallint(6) NOT NULL COMMENT '版本类型',
  `version_url` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '版本地址',
  `update_datetime` datetime NOT NULL COMMENT '生效日期',
  `version_comment` longtext COLLATE utf8mb4_unicode_ci COMMENT '版本备注',
  `creator_id` int(11) NOT NULL COMMENT '创建人ID',
  `created_datetime` datetime NOT NULL COMMENT '创建日期',
  `modify_id` int(11) DEFAULT NULL COMMENT '修改人ID',
  `modify_datetime` datetime DEFAULT NULL COMMENT '最后修改日期',
  PRIMARY KEY (`version_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `mbss_version_force` (
  `version_id` int(11) NOT NULL COMMENT '版本ID',
  `history_version_id` int(11) NOT NULL COMMENT '历史版本ID',
  `flag_forced` tinyint(4) NOT NULL COMMENT '强制升级',
  PRIMARY KEY (`version_id`,`history_version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `mbss_video` (
  `pic_id` bigint(20) NOT NULL COMMENT '图片ID',
  `video_url` varchar(256) DEFAULT NULL COMMENT '图片url',
  `video_id` int(50) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `video_state` smallint(6) DEFAULT NULL COMMENT '视频状态(0:已删除，1：待审核，2：审核通过,3:审核失败)',
  `user_id` int(11) NOT NULL,
  `channel_name` varchar(50) DEFAULT NULL,
  `channel_summary` varchar(256) DEFAULT NULL,
  `cover_image` varchar(256) DEFAULT NULL,
  `channel_id` int(11) DEFAULT NULL,
  `channel_web_Id` varchar(256) NOT NULL,
  `length` int(11) DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `fid` varchar(50) DEFAULT NULL COMMENT 'fid',
  `creator` int(11) DEFAULT NULL COMMENT '创建人',
  `created_datetime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`pic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
